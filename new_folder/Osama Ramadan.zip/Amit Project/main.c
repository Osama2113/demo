#include <stdio.h>


void SDB_APP();
               /*WE USE THE VOID FUNCTION TO SOLVE THE IMPLICIT DECLARATION ERROR
                  AS ( SDB_APP() ) NOT DECLARED*/
int main(){

	 SDB_APP();

	return 0;
}



